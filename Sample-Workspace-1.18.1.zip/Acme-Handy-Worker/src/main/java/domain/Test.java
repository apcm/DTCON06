package domain;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Sex";
		s1.toLowerCase();
		String s2="sex";
		System.out.println(s1);
		System.out.println(s2);
	}

}
